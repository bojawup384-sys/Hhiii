import { pool } from "@/db";

/**
 * Idempotent bootstrap: creates the tables/indexes if they don't exist yet, so a
 * fresh database works right after the first deploy — no `drizzle-kit push` needed.
 * Mirrors src/db/schema.ts (keep both in sync when you change the schema).
 */
const DDL = `
create table if not exists users (
  id text primary key,
  email text not null,
  display_name text,
  photo_url text,
  locale text not null default 'ar',
  plan text not null default 'free',
  plan_expires_at timestamptz,
  credits_used integer not null default 0,
  usage_day text,
  total_runs integer not null default 0,
  created_at timestamptz not null default now(),
  last_seen_at timestamptz not null default now()
);

create table if not exists conversations (
  id uuid primary key default gen_random_uuid(),
  user_id text not null references users(id) on delete cascade,
  title text not null default '',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists conv_user_idx on conversations (user_id, updated_at);

create table if not exists messages (
  id uuid primary key default gen_random_uuid(),
  conversation_id uuid not null references conversations(id) on delete cascade,
  role text not null,
  content text not null,
  created_at timestamptz not null default now()
);
create index if not exists msg_conv_idx on messages (conversation_id, created_at);

create table if not exists tool_runs (
  id uuid primary key default gen_random_uuid(),
  user_id text not null references users(id) on delete cascade,
  tool text not null,
  title text not null default '',
  input text not null,
  output text not null,
  created_at timestamptz not null default now()
);
create index if not exists runs_user_idx on tool_runs (user_id, created_at);

create table if not exists orders (
  id uuid primary key default gen_random_uuid(),
  user_id text not null references users(id) on delete cascade,
  plan text not null default 'pro',
  period text not null default 'monthly',
  amount_dzd integer not null,
  status text not null default 'pending',
  provider text not null default 'chargily',
  provider_ref text,
  created_at timestamptz not null default now()
);
create index if not exists orders_user_idx on orders (user_id);

create table if not exists promo_codes (
  code text primary key,
  plan text not null default 'pro',
  days integer not null default 30,
  max_uses integer not null default 100,
  used integer not null default 0,
  active boolean not null default true,
  created_at timestamptz not null default now()
);
`;

const g = globalThis as typeof globalThis & {
  __barqSchemaReady?: Promise<void>;
};

async function run(): Promise<void> {
  try {
    await pool.query(DDL);
  } catch (first) {
    // two cold instances can race on CREATE TABLE — one retry is enough
    await new Promise((r) => setTimeout(r, 300));
    try {
      await pool.query(DDL);
    } catch {
      throw first;
    }
  }
}

/** Runs once per server instance; a failed attempt is retried on the next call. */
export function ensureSchema(): Promise<void> {
  if (!g.__barqSchemaReady) {
    g.__barqSchemaReady = run().catch((e) => {
      g.__barqSchemaReady = undefined;
      throw e;
    });
  }
  return g.__barqSchemaReady;
}
