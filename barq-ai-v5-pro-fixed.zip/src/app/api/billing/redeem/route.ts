import { json, serverError } from "@/lib/http";
import { rateLimit } from "@/lib/rate-limit";
import { verifyRequest } from "@/lib/server-auth";
import { ensureUser } from "@/lib/usage";
import { ensureSchema } from "@/db/ensure-schema";
import { db } from "@/db";
import { orders, promoCodes, users } from "@/db/schema";
import { and, eq, sql } from "drizzle-orm";
import {
  PRO_CODE_MAX_USES,
  PRO_DAYS,
  isAllowedCode,
  normalizeCode,
} from "@/lib/promo";

export const runtime = "nodejs";

/** POST { code } — redeems one of the fixed promo codes and activates Barq v5 Pro */
export async function POST(req: Request) {
  const user = await verifyRequest(req);
  if (!user) return json(401, { code: "UNAUTHENTICATED" });

  // slow down code guessing
  const rl = rateLimit(`redeem:${user.uid}`, 8, 60_000);
  if (!rl.ok) {
    return json(429, { code: "RATE" }, { "Retry-After": String(rl.retryAfter) });
  }

  let code = "";
  try {
    const body = (await req.json()) as { code?: unknown };
    code = typeof body.code === "string" ? normalizeCode(body.code) : "";
  } catch {
    return json(400, { code: "BAD_BODY" });
  }
  if (!code || code.length > 40 || !isAllowedCode(code)) {
    return json(400, { code: "INVALID_CODE" });
  }

  try {
    await ensureSchema();
    await ensureUser(user);

    // Everything in ONE transaction: if any step fails the code is NOT burned,
    // and the atomic UPDATE guarantees a code can never be claimed twice.
    const result = await db.transaction(async (tx) => {
      await tx
        .insert(promoCodes)
        .values({ code, plan: "pro", days: PRO_DAYS, maxUses: PRO_CODE_MAX_USES })
        .onConflictDoNothing();

      // single use, whatever max_uses says in the database
      const claimed = await tx
        .update(promoCodes)
        .set({ used: sql`${promoCodes.used} + 1`, active: false })
        .where(
          and(
            eq(promoCodes.code, code),
            eq(promoCodes.active, true),
            sql`${promoCodes.used} < 1`
          )
        )
        .returning({ code: promoCodes.code });
      if (claimed.length === 0) return null;

      const u = (
        await tx.select().from(users).where(eq(users.id, user.uid)).limit(1)
      )[0];
      const baseMs =
        u &&
        u.plan === "pro" &&
        u.planExpiresAt &&
        u.planExpiresAt.getTime() > Date.now()
          ? u.planExpiresAt.getTime()
          : Date.now();
      const expires = new Date(baseMs + PRO_DAYS * 86_400_000);

      await tx
        .update(users)
        .set({ plan: "pro", planExpiresAt: expires })
        .where(eq(users.id, user.uid));

      await tx.insert(orders).values({
        userId: user.uid,
        plan: "pro",
        period: "monthly",
        amountDzd: 0,
        status: "paid",
        provider: "promo",
        providerRef: code,
      });
      return expires;
    });

    if (!result) return json(400, { code: "INVALID_CODE" });

    return json(200, {
      ok: true,
      days: PRO_DAYS,
      plan: "pro",
      expiresAt: result.toISOString(),
    });
  } catch (e) {
    return serverError("redeem", e, "DB");
  }
}
