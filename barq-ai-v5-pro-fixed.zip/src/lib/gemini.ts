/**
 * Gemini streaming client — plain REST, no SDK required.
 * Configure in Vercel: GEMINI_API_KEY (or GOOGLE_API_KEY / GOOGLE_GENERATIVE_AI_API_KEY)
 */

export type ChatTurn = { role: "user" | "model"; text: string };

/** Binary input (image / PDF) sent inline to Gemini — Pro only. */
export type Attachment = { mime: string; data: string };

/** Which engine room a request runs in. */
export type Tier = "free" | "pro";
/** "speed" = newest fast model; "quality" = strongest model available (Pro only). */
export type Mode = "speed" | "quality";

/** Static fallbacks, used only when model discovery is not possible. */
const FALLBACK_FREE = [
  "gemini-2.5-flash",
  "gemini-2.5-flash-lite",
  "gemini-2.0-flash",
  "gemini-flash-latest",
  "gemini-flash-lite-latest",
];
const FALLBACK_FAST = [
  "gemini-flash-latest",
  "gemini-2.5-flash",
  "gemini-2.5-flash-lite",
  "gemini-flash-lite-latest",
];
const FALLBACK_MAX = [
  "gemini-pro-latest",
  "gemini-2.5-pro",
  "gemini-flash-latest",
  "gemini-2.5-flash",
];
/** Kept for the diagnostics route. */
export const FALLBACK_MODELS = FALLBACK_FAST;
export const MODELS = FALLBACK_FAST;

export class GeminiError extends Error {
  code: "NO_KEY" | "BUSY" | "ERROR";
  detail: string;
  constructor(code: "NO_KEY" | "BUSY" | "ERROR", message: string) {
    super(message);
    this.code = code;
    this.detail = message.slice(0, 300);
  }
}

const KEY_NAMES = [
  "GEMINI_API_KEY",
  "GOOGLE_API_KEY",
  "GOOGLE_GENERATIVE_AI_API_KEY",
  "GOOGLE_AI_API_KEY",
  "GEMINI_KEY",
  "GEMINI_APIKEY",
  "GEMINI",
  "API_KEY",
  "APIKEY",
  "KEY",
];

function clean(v: string | undefined): string {
  // strip spaces, newlines and accidental quotes pasted with the key
  return (v ?? "").trim().replace(/^["'`]+|["'`]+$/g, "").trim();
}

/** Returns which env var holds the key (name only) and the cleaned value. */
export function findGeminiKey(): { name: string; value: string } | undefined {
  const env = process.env;
  const upper = new Map<string, string>();
  for (const k of Object.keys(env)) upper.set(k.toUpperCase(), k);

  // 1) well-known names, case-insensitive
  for (const n of KEY_NAMES) {
    const real = upper.get(n);
    const v = real ? clean(env[real]) : "";
    if (v) return { name: real as string, value: v };
  }
  // 2) last resort: any non-public variable that looks like a Google AI key
  for (const k of Object.keys(env)) {
    if (k.startsWith("NEXT_PUBLIC_")) continue; // Firebase web key lives there
    const v = clean(env[k]);
    if (/^AIza[0-9A-Za-z_-]{30,}$/.test(v)) return { name: k, value: v };
  }
  return undefined;
}

export function getGeminiKey(): string | undefined {
  return findGeminiKey()?.value;
}

async function openStream(
  model: string,
  key: string,
  body: unknown,
  signal?: AbortSignal
): Promise<Response> {
  const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:streamGenerateContent?alt=sse`;
  return fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json", "x-goog-api-key": key },
    body: JSON.stringify(body),
    cache: "no-store",
    signal,
  });
}

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

type ModelSets = { free: string[]; fast: string[]; max: string[] };
const FALLBACK_SETS: ModelSets = {
  free: FALLBACK_FREE,
  fast: FALLBACK_FAST,
  max: FALLBACK_MAX,
};

/**
 * Asks Google which models this key can really use, so a retired model name
 * can never break the app. Cached for 30 min per server instance.
 */
const gm = globalThis as typeof globalThis & {
  __barqModels?: { at: number; sets: ModelSets };
  __barqModelsP?: Promise<ModelSets>;
};

/** Cached sets, or at most ~1.5s of waiting before falling back to the static ones. */
async function getModelSets(key: string): Promise<ModelSets> {
  const c = gm.__barqModels;
  if (c && Date.now() - c.at < 30 * 60_000) return c.sets;
  if (!gm.__barqModelsP) {
    gm.__barqModelsP = discoverModels(key).finally(() => {
      gm.__barqModelsP = undefined;
    });
  }
  return Promise.race([
    gm.__barqModelsP,
    sleep(1500).then(() => FALLBACK_SETS),
  ]);
}

const NEVER = /(image|tts|live|audio|embedding|robotics|computer|native|vision|learnlm|gemma|aqa)/;
const UNSTABLE = /(exp|preview|thinking)/;

function versionOf(n: string): number {
  const v = n.match(/gemini-(\d+(?:\.\d+)?)/);
  return v ? parseFloat(v[1]) : 0;
}

async function discoverModels(key: string): Promise<ModelSets> {
  try {
    const res = await fetch(
      "https://generativelanguage.googleapis.com/v1beta/models?pageSize=200",
      {
        headers: { "x-goog-api-key": key },
        cache: "no-store",
        signal: AbortSignal.timeout(6000),
      }
    );
    if (!res.ok) return rememberFallback();
    const data = (await res.json()) as {
      models?: { name?: string; supportedGenerationMethods?: string[] }[];
    };
    const names = Array.from(
      new Set(
        (data.models ?? [])
          .filter((m) => m.supportedGenerationMethods?.includes("generateContent"))
          .map((m) => (m.name ?? "").replace(/^models\//, ""))
          .filter((n) => /^gemini-/.test(n) && !NEVER.test(n))
      )
    );
    const flash = names.filter((n) => /flash/.test(n));
    const pro = names.filter((n) => /-pro/.test(n));
    if (flash.length === 0) return rememberFallback();

    const byScore = (score: (n: string) => number) => (x: string, y: string) =>
      score(y) - score(x);

    // FREE: stable flash only, steady and predictable ("lite" last).
    const stableScore = (n: string) =>
      versionOf(n) * 100 - (/lite/.test(n) ? 150 : 0) - (/-latest$/.test(n) ? 40 : 0);
    const free = flash
      .filter((n) => !UNSTABLE.test(n))
      .sort(byScore(stableScore))
      .slice(0, 5);

    // PRO / speed: the newest flash of all — aliases and previews included.
    const fastScore = (n: string) =>
      (n === "gemini-flash-latest" ? 1000 : 0) +
      versionOf(n) * 100 -
      (/lite/.test(n) ? 150 : 0) -
      (/(exp|thinking)/.test(n) ? 500 : 0) -
      (/preview/.test(n) ? 20 : 0);
    const fast = flash.sort(byScore(fastScore)).slice(0, 4);

    // PRO / quality: the strongest pro model first, then the fast set as a net.
    const maxScore = (n: string) =>
      (n === "gemini-pro-latest" ? 1000 : 0) +
      versionOf(n) * 100 -
      (/(exp|thinking)/.test(n) ? 500 : 0) -
      (/preview/.test(n) ? 20 : 0);
    const max = pro.sort(byScore(maxScore)).slice(0, 2);

    const uniq = (l: string[]) => Array.from(new Set(l));
    const sets: ModelSets = {
      free: free.length ? free : FALLBACK_FREE,
      fast: uniq([...fast, ...(free.length ? free : FALLBACK_FREE)]).slice(0, 6),
      max: uniq([...max, ...fast, ...free]).slice(0, 6),
    };
    gm.__barqModels = { at: Date.now(), sets };
    return sets;
  } catch {
    return rememberFallback();
  }
}

function rememberFallback(): ModelSets {
  // pretend it was fetched 28 min ago: re-checked after ~2 minutes
  gm.__barqModels = { at: Date.now() - 28 * 60_000, sets: FALLBACK_SETS };
  return FALLBACK_SETS;
}

/** 2.5+/3 models "think" by default and can burn the whole token budget silently. */
function configFor(
  model: string,
  base: Record<string, unknown>,
  deep: boolean
): Record<string, unknown> {
  if (/gemini-2\.5/.test(model)) {
    return {
      ...base,
      thinkingConfig: { thinkingBudget: deep ? 2048 : 0 },
    };
  }
  return base;
}

type Attempt =
  | { ok: true; res: Response; model: string }
  | { ok: false; status: number; text: string; model: string };

const isBadKey = (a: { status: number; text: string }) =>
  a.status === 401 ||
  a.status === 403 ||
  /API_KEY_INVALID|API key not valid|API key expired|PERMISSION_DENIED/i.test(a.text);

/** One model, one try. Handles models that reject thinkingConfig. */
async function attempt(
  model: string,
  key: string,
  mk: (m: string) => { generationConfig: Record<string, unknown> } & Record<string, unknown>,
  baseGen: Record<string, unknown>,
  signal?: AbortSignal
): Promise<Attempt> {
  try {
    let res = await openStream(model, key, mk(model), signal);
    if (res.status === 400) {
      const t400 = await res.text().catch(() => "");
      if (/thinking/i.test(t400)) {
        const b = mk(model);
        b.generationConfig = baseGen;
        res = await openStream(model, key, b, signal);
      } else {
        return { ok: false, status: 400, text: t400.slice(0, 300), model };
      }
    }
    if (res.ok && res.body) return { ok: true, res, model };
    const text = await res.text().catch(() => "");
    return { ok: false, status: res.status, text: text.slice(0, 300), model };
  } catch (e) {
    return { ok: false, status: 0, text: String(e).slice(0, 200), model };
  }
}

/**
 * PRO "ultra speed": candidates start staggered (0 / 1.8s / 3.6s) or immediately
 * when an earlier one fails — the first healthy stream wins, the rest are cancelled.
 */
function hedged(
  models: string[],
  key: string,
  mk: Parameters<typeof attempt>[2],
  baseGen: Record<string, unknown>
): Promise<{ winner?: Extract<Attempt, { ok: true }>; fails: Attempt[] }> {
  const list = models.slice(0, 3);
  const n = list.length;
  const ctrls = list.map(() => new AbortController());
  const fails: Attempt[] = [];
  const started = new Set<number>();
  const timers: ReturnType<typeof setTimeout>[] = [];
  let settled = false;
  let failed = 0;

  return new Promise((resolve) => {
    const finish = (winner?: Extract<Attempt, { ok: true }>, keep = -1) => {
      settled = true;
      timers.forEach(clearTimeout);
      ctrls.forEach((c, j) => {
        if (j !== keep) c.abort();
      });
      resolve({ winner, fails });
    };
    const startNext = () => {
      for (let i = 0; i < n; i++) {
        if (!started.has(i)) return start(i);
      }
    };
    const start = (i: number) => {
      if (settled || started.has(i) || i >= n) return;
      started.add(i);
      void attempt(list[i], key, mk, baseGen, ctrls[i].signal).then((a) => {
        if (settled) {
          if (a.ok) a.res.body?.cancel().catch(() => undefined);
          return;
        }
        if (a.ok) return finish(a, i);
        fails.push(a);
        failed += 1;
        if (isBadKey(a) || failed >= n) return finish();
        startNext();
      });
    };
    start(0);
    for (let i = 1; i < n; i++) timers.push(setTimeout(() => start(i), i * 1800));
  });
}

/**
 * Opens a Gemini SSE stream and returns a ReadableStream of text chunks.
 * `onDone` fires once with the full accumulated text (even on mid-stream
 * failure it receives the partial text).
 *
 * tier "pro": newest models + hedged requests (ultra speed), attachments allowed,
 *             bigger output budget, optional "quality" mode (strongest model).
 */
export async function streamGemini(opts: {
  system: string;
  messages: ChatTurn[];
  temperature?: number;
  tier?: Tier;
  mode?: Mode;
  maxTokens?: number;
  /** images / PDFs attached to the LAST user turn (ignored for free tier) */
  attachments?: Attachment[];
  onModel?: (model: string) => void;
  onDone?: (full: string) => void | Promise<void>;
}): Promise<ReadableStream<string>> {
  const key = getGeminiKey();
  if (!key) {
    throw new GeminiError("NO_KEY", "Gemini API key is not configured");
  }

  const pro = opts.tier === "pro";
  const quality = pro && opts.mode === "quality";
  const baseGen = {
    temperature: opts.temperature ?? 0.75,
    maxOutputTokens: opts.maxTokens ?? (pro ? 8192 : 4096),
    topP: 0.95,
  };
  const atts = pro ? (opts.attachments ?? []) : [];
  const lastIdx = opts.messages.length - 1;
  const mk = (model: string) => ({
    systemInstruction: { parts: [{ text: opts.system }] },
    contents: opts.messages.map((m, i) => ({
      role: m.role,
      parts:
        i === lastIdx && m.role === "user" && atts.length > 0
          ? [
              ...atts.map((a) => ({
                inlineData: { mimeType: a.mime, data: a.data },
              })),
              { text: m.text },
            ]
          : [{ text: m.text }],
    })),
    generationConfig: configFor(model, baseGen, quality),
  });

  const sets = await getModelSets(key);
  const models = quality ? sets.max : pro ? sets.fast : sets.free;

  let upstream: Response | null = null;
  let usedModel = "";
  let lastErr = "";
  // set inside closures below, so keep them typed as plain booleans
  let sawQuota = false as boolean;
  let sawBadKey = false as boolean;
  let sawOverload = false as boolean;

  const note = (a: Attempt) => {
    if (a.ok) return;
    lastErr = `${a.model}: ${a.status} ${a.text}`;
    if (a.status === 429) sawQuota = true; // quotas are per-model: try the next one
    if (a.status === 0 || a.status === 500 || a.status === 503 || a.status === 504) {
      sawOverload = true;
    }
    if (isBadKey(a)) sawBadKey = true;
  };

  for (let round = 0; round < 2 && !upstream; round++) {
    if (pro && !quality) {
      // quality mode waits for the strong model; only speed mode races candidates
      const r = await hedged(models, key, mk, baseGen);
      r.fails.forEach(note);
      if (r.winner) {
        upstream = r.winner.res;
        usedModel = r.winner.model;
        break;
      }
    } else {
      for (const model of models) {
        const a = await attempt(model, key, mk, baseGen);
        if (a.ok) {
          upstream = a.res;
          usedModel = a.model;
          break;
        }
        note(a);
        if (sawBadKey) break; // another model will not fix a bad key
      }
    }
    if (upstream || sawBadKey) break;
    // everything was overloaded / limited: wait a moment and go around once more
    if ((sawOverload || sawQuota) && round === 0) await sleep(pro ? 500 : 1200);
    else break;
  }

  if (!upstream && sawBadKey) {
    console.error("[gemini] invalid key:", lastErr);
    throw new GeminiError("NO_KEY", lastErr);
  }
  if (!upstream && (sawQuota || sawOverload)) {
    console.error("[gemini] busy:", lastErr);
    throw new GeminiError("BUSY", lastErr);
  }
  if (!upstream) console.error("[gemini] failed:", lastErr);

  if (!upstream || !upstream.body) {
    throw new GeminiError("ERROR", lastErr || "All models failed");
  }
  opts.onModel?.(usedModel);

  const decoder = new TextDecoder();
  const full: string[] = [];

  let cancelled = false;
  const upstreamRef: { r: ReadableStreamDefaultReader<Uint8Array> | null } = {
    r: null,
  };

  const stream = new ReadableStream<string>({
    async start(controller) {
      const reader = (upstream as Response).body!.getReader();
      upstreamRef.r = reader;
      let buffer = "";
      try {
        for (;;) {
          if (cancelled) break;
          const { done, value } = await reader.read();
          if (done) break;
          buffer += decoder.decode(value, { stream: true });

          let idx: number;
          // eslint-disable-next-line no-cond-assign
          while ((idx = buffer.indexOf("\n")) >= 0) {
            const line = buffer.slice(0, idx).trim();
            buffer = buffer.slice(idx + 1);
            if (!line.startsWith("data:")) continue;
            const payload = line.slice(5).trim();
            if (!payload || payload === "[DONE]") continue;
            try {
              const json = JSON.parse(payload);
              const parts =
                json?.candidates?.[0]?.content?.parts ??
                ([] as { text?: string }[]);
              for (const p of parts) {
                if (typeof p.text === "string" && p.text.length > 0) {
                  full.push(p.text);
                  if (!cancelled) controller.enqueue(p.text);
                }
              }
            } catch {
              // incomplete JSON line — ignore
            }
          }
        }
      } catch {
        // network hiccup: keep partial text
      } finally {
        if (full.length === 0 && !cancelled) {
          // blocked / empty answer: never leave the user with a blank bubble
          controller.enqueue("تعذّر توليد رد على هذه الرسالة، جرّب صياغة مختلفة.");
        }
        try {
          await opts.onDone?.(full.join(""));
        } catch {
          // persistence errors must never break the stream
        }
        try {
          controller.close();
        } catch {
          // already closed by a client disconnect
        }
      }
    },
    cancel() {
      cancelled = true;
      upstreamRef.r?.cancel().catch(() => undefined);
    },
  });

  return stream;
}

/** Stream → web Response with text/plain body */
export function streamToResponse(
  stream: ReadableStream<string>,
  headers: Record<string, string> = {}
): Response {
  const encoded = stream.pipeThrough(new TextEncoderStream());
  return new Response(encoded, {
    headers: {
      "Content-Type": "text/plain; charset=utf-8",
      "Cache-Control": "no-store",
      ...headers,
    },
  });
}
